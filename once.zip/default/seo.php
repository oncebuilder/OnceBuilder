<?php
# SECURE -----------------
if(!$home) exit;

# PAGE SEO -----------------

$_SEO['testseo']['description']='Descriptions';
$_SEO['testseo']['description']='Descriptions';
$_SEO['testseo']['description']='Descriptions';
?>