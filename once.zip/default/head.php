<title><?php echo $_LANGS['i1'];?></title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="keywords" content="<?php echo $_LANGS['i2'];?>">
<meta name="description" content="<?php echo $_LANGS['i3'];?>">
<meta name="robots" content="index,follow">
<meta name="author" content="OnceBuilder" />
<meta name="revisit-after" content="3 days" />

<!-- facebook meta -->
<meta property="og:title" content="<?php echo $_LANGS['i1'];?>" /> 
<meta property="og:type" content="article"/>
<meta property="og:description" content="Your topic on facebook." /> 
<meta property="og:url" content="<?php echo $_ROUTE['domian'].'/'.$_GET['id'];?>"/>
<meta property="og:image" content="<?php echo $_ROUTE['domian'];?>/logo.jpg" />

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap-theme.min.css">