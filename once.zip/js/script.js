// Once configuration
once.api = true;
once.cms = true;
once.admin = true;
once.creator = true;
once.path = '/once';

$(document).ready(function () {
	$(".sidebar-toggle").click(function (e) {
		//alert('save cookie');
	});
});