$(document).ready(function () {
	$(".sidebar-toggle").click(function (e) {
		//alert('save cookie');
	});
});