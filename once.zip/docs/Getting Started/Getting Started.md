<h1>
				  Quick Start
				  <a href="https://github.com/oncebuilder/oncebuilder/guildeness/quick-start.md" target="_blank" class="edit-page icon-pencil">Edit Page</a>
				</h1>
				<hr>

				<p>This guide will teach you how to build a simple app using OnceBuilder from scratch.</p>
				<ol>
					<li>Installing OnceBuilder</li>
					<li>Creating a new application.</li>
					<li>Creating a page & defining a route</li>
				</ol>
				<h2></a>Install OnceBuilder</h2>
				<p>
					You can install OnceBuilder with a single command using npm,
					the Node.js package manager.
					Type this into your terminal:
				</p>
				<pre>npm install -g oncebuilder</pre>
						<p>In your browser, open <a href="http://localhost/once/"><code>http://localhost/once/</code></a>.
						When you run oncebuilder first time, you should see DB installer & create account form.</p>