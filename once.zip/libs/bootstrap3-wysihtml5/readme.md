New Version
=============

Now new joint development: https://github.com/bootstrap-wysiwyg/bootstrap3-wysiwyg
